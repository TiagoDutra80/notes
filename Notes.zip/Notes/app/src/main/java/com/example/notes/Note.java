package com.example.notes;

public class Note {

    public int id;

    public String contents;
}
